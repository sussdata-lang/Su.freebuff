import fs from 'node:fs';
import path from 'node:path';
import { log } from './lib/logger.js';

export class HttpError extends Error {
  constructor(status, message, code = 'error', field = undefined) { super(message); this.status = status; this.code = code; this.field = field; }
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.json': 'application/json; charset=utf-8', '.ico': 'image/x-icon', '.png': 'image/png',
  '.webmanifest': 'application/manifest+json; charset=utf-8', '.ttf': 'font/ttf', '.woff2': 'font/woff2' };

// ترويسات أمنية: لا سكربتات إلا من الموقع نفسه، ولا تضمين في إطارات، ولا تخمين لأنواع الملفات
// style-src يحوي 'unsafe-inline' عمداً: الواجهة تولّد سمات style= كثيرة في القوالب؛ أزيلت ولم يبقَ إلا CSS خارجي يتطلب إعادة كتابة شاملة للقوالب.
// HSTS: المتصفحات تتجاهله فوق http، ويأخذ أثره فور تفعيل HTTPS؛ CORP يمنع موارد الموقع من التضمين عبر مواقع أخرى.
export const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; media-src 'self' https:; frame-src https://www.youtube-nocookie.com https://player.vimeo.com; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'Permissions-Policy': 'camera=(self), microphone=(), geolocation=()',
};

// فحص أصل الطلب (دفاع في العمق ضد CSRF بجانب SameSite=Strict):
// المتصفح يضع ترويسة Origin على كل طلب تعديل؛ تُقبل إذا طابق مضيف الخادم (Host) أو PUBLIC_URL،
// ويرفض Origin مختلف أو 'null' (iframe معزول/ملف محلي). غياب الترويسة مسموح (طلبات غير متصفح مثل curl أو تطبيق جوال).
export function originAllowed(cfg, req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  if (origin === 'null') return false;
  let host; try { host = new URL(origin).host; } catch { return false; }
  const allowed = new Set([req.headers.host]);
  if (cfg.publicUrl) { try { allowed.add(new URL(cfg.publicUrl).host); } catch { /* PUBLIC_URL غير صالح يُتجاهل */ } }
  return allowed.has(host);
}

// ترميز ناقص أو تالف (مثل %zz أو تسلسل UTF-8 غير مكتمل) في ملف تعريف أو مسار:
// يبقى النص كما هو بدل رمي URIError الذي كان سيُنتج خطأ 500 داخلياً
const safeDecode = (s) => { try { return decodeURIComponent(s); } catch { return s; } };

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = safeDecode(part.slice(i + 1).trim());
  }
  return out;
}

export class Router {
  constructor() { this.routes = []; }
  add(method, pattern, handler, opts = {}) {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-z_]+)/gi, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
    this.routes.push({ method, re, keys, handler, opts });
  }
  match(method, pathname) {
    let pathMatched = false;
    for (const r of this.routes) {
      const m = r.re.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method) continue;
      const params = {};
      r.keys.forEach((k, i) => { params[k] = safeDecode(m[i + 1]); });
      return { route: r, params };
    }
    return { route: null, pathMatched };
  }
}

async function readRaw(req, limit) {
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > limit) throw new HttpError(413, 'حجم الملف أكبر من المسموح.', 'too_large'); chunks.push(c); }
  return Buffer.concat(chunks);
}

async function readBody(req, limit) {
  const chunks = []; let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new HttpError(413, 'حجم الطلب أكبر من المسموح.', 'too_large');
    chunks.push(c);
  }
  if (!size) return {};
  if (!/^application\/json/i.test(req.headers['content-type'] || '')) throw new HttpError(415, 'يُقبل JSON فقط.', 'bad_content_type');
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new HttpError(400, 'JSON غير صالح.', 'bad_json'); }
}

export function sendJson(res, status, obj, headers = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

function serveStatic(cfg, pathname, res) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(cfg.publicDir, rel));
  if (!file.startsWith(cfg.publicDir + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return false;
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] ?? 'application/octet-stream', 'Cache-Control': 'no-cache', ...SECURITY_HEADERS });
  fs.createReadStream(file).pipe(res);
  return true;
}

export function makeHandler({ cfg, router, getUser }) {
  return async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const ip = (cfg.trustProxy && req.headers['x-forwarded-for']?.split(',')[0].trim()) || req.socket.remoteAddress;
    try {
      if (!url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'الطريقة غير مسموحة.');
        if (serveStatic(cfg, url.pathname, res)) return;
        throw new HttpError(404, 'غير موجود.', 'not_found');
      }
      const { route, params, pathMatched } = router.match(req.method, url.pathname);
      if (!route) throw new HttpError(pathMatched ? 405 : 404, pathMatched ? 'الطريقة غير مسموحة.' : 'غير موجود.', 'not_found');
      // فحص الأصل قبل قراءة الحمولة: يرفض طلبات التعديل من مصادر أخرى فوراً
      if (req.method !== 'GET' && req.method !== 'HEAD' && !originAllowed(cfg, req))
        throw new HttpError(403, 'مصدر الطلب غير مسموح.', 'bad_origin');
      const cookies = parseCookies(req.headers.cookie);
      const user = getUser(cookies.sid);   // مسارات auth:false (مثل /api/me) تقرأ المستخدم إن وُجد دون إلزام
      if (route.opts.auth !== false && !user) throw new HttpError(401, 'يلزم تسجيل الدخول.', 'unauthenticated');
      // كلمة المرور المؤقتة: لا شيء يعمل قبل تغييرها سوى تغييرها والخروج
      if (route.opts.auth !== false && user?.must_change_password && !route.opts.allowMustChange) throw new HttpError(403, 'يجب تغيير كلمة المرور المؤقتة أولاً.', 'password_change_required');
      const ctx = { req, res, ip, params, query: Object.fromEntries(url.searchParams), cookies, user, cfg,
        body: req.method === 'GET' ? {} : route.opts.raw ? await readRaw(req, route.opts.maxBody) : await readBody(req, route.opts.maxBody ?? 64 * 1024),
        json: (status, obj, headers) => sendJson(res, status, obj, headers) };
      await route.handler(ctx);
    } catch (e) {
      if (e instanceof HttpError) return sendJson(res, e.status, { error: e.code, message: e.message, ...(e.field ? { field: e.field } : {}) });
      log.error(`${req.method} ${String(req.url).split('?')[0]}`, e);
      sendJson(res, 500, { error: 'internal', message: 'خطأ داخلي في الخادم.' });
    }
  };
}

export function sendRaw(res, status, headers, body) {
  res.writeHead(status, { 'Cache-Control': 'no-store', ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

// بثّ ملف كبير (نسخة احتياطية مثلاً) بدل تحميله كاملاً في الذاكرة
export function sendStream(res, status, headers, stream) {
  res.writeHead(status, { 'Cache-Control': 'no-store', ...SECURITY_HEADERS, ...headers });
  stream.pipe(res);
}
