// 5.7 الموارد البشرية والرواتب
// القائمة: جدول الموظفين مع فلترة (بحث، وحدة، حالة، قسم) + تفعيل/إجازة
// التفاصيل: بيانات الموظف، صفحة الراتب الحالي، الإجازات، العقود، فلاتر الصلاحيات داخل الوحدة
try {
  const $ = (id) => document.getElementById(id);
  const LS = {
    emp: () => JSON.parse(localStorage.getItem('hr_employees') || 'null') ?? null,
    setEmp(v) { localStorage.setItem('hr_employees', JSON.stringify(v)); },
    unitOptions() { return JSON.parse(localStorage.getItem('hr_unit_options') || '[]'); },
  };

  const statusOpts = [{ key: 'active', label: 'مفعّل' }, { key: 'on_leave', label: 'في إجازة' }, { key: 'terminated', label: 'منتهي' }];
  const leaveTypeOpts = [{ key: 'annual', label: 'إجازة سنوية' }, { key: 'sick', label: 'إجازة مرضية' }, { key: 'unpaid', label: 'إجازة بدون راتب' }];
  const contractTypeOpts = [{ key: 'fixed', label: 'محدد المدة' }, { key: 'indefinite', label: 'غير محدد المدة' }, { key: 'temporary', label: 'مؤقت' }, { key: 'freelance', label: 'مستقل' }];

  let employees = LS.emp() ?? [];
  let employeesLoaded = false;
  let unitOptions = LS.unitOptions();
  let unitCache = new Map();
  let filters = { search: '', unitId: '', status: '', type: '', page: 1, limit: 50 };
  let leaves = [];
  let contracts = [];
  let currentEmpId = null;

  async function api(method, url, body) {
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body !== undefined ? JSON.stringify(body) : undefined });
    if (!res.ok) { const j = await res.json().catch(() => ({ error: res.statusText })); throw new Error(j.error || `خادم: ${res.status}`); }
    return res.json();
  }

  function el(tag, attrs = {}, children = []) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) { if (k === 'class') e.className = v; else if (k === 'textContent') e.textContent = v; else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v); else if (v !== undefined && v !== null && v !== false) e.setAttribute(k, v); }
    for (const c of children) e.append(c instanceof Node ? c : document.createTextNode(String(c)));
    return e;
  }

  function fmtDate(ts) { if (!ts) return '—'; try { const d = new Date(Number(ts)); return isNaN(d) ? String(ts) : d.toLocaleDateString('ar-SA'); } catch { return String(ts); } }
  function fmtNum(n) { if (n === undefined || n === null) return '—'; return Number(n).toLocaleString('ar-SA'); }

  function init() {
    attachEvents();
    loadUnits();
    applyFilters();
  }

  function loadUnits() {
    fetch('/api/units').then(async r => { const u = await r.json(); unitOptions = u.units?.map(x => ({ key: x.id, label: x.name })); LS.setUnitOptions(unitOptions); });
  }

  function attachEvents() {
    $('f-search').addEventListener('input', e => { filters.search = e.target.value; applyFilters(); });
    $('f-unit').addEventListener('change', e => { filters.unitId = e.target.value; applyFilters(); });
    $('f-status').addEventListener('change', e => { filters.status = e.target.value; applyFilters(); });
    $('f-type').addEventListener('change', e => { filters.type = e.target.value; applyFilters(); });
    $('btn-add').addEventListener('click', () => showAddModal());
    $('btn-salary').addEventListener('click', () => showSalaryModal());
    $('btn-leaves').addEventListener('click', () => showLeavesModal());
    $('btn-contracts').addEventListener('click', () => showContractsModal());
  }

  async function loadEmployees() {
    const q = new URLSearchParams({ search: filters.search, unitId: filters.unitId, status: filters.status, type: filters.type, page: filters.page, size: filters.limit });
    const r = await api('GET', `/api/admin/hr/employees?${q}`);
    employees = r.employees ?? [];
    LS.setEmp(employees);
    employeesLoaded = true;
    applyFilters();
  }

  function applyFilters() {
    const rows = document.getElementById('emp-rows');
    if (!employeesLoaded) { rows.innerHTML = '<tr><td colspan="8" class="muted">تحميل الموظفين…</td></tr>'; $('emp-pager').hidden = true; return; }
    let list = employees.filter(m => (!filters.search || m.name.includes(filters.search) || (m.employeeNo||'').includes(filters.search)) && (!filters.unitId || m.unitId == filters.unitId) && (!filters.status || m.status === filters.status));
    const span = $('emp-count');
    span.textContent = `عرض ${list.length} موظفًا`;
    if (!list.length) { rows.innerHTML = '<tr><td colspan="8" class="muted">لا يوجد موظفون مطابقون</td></tr>'; $('emp-pager').hidden = true; return; }
    rows.innerHTML = list.map(m => {
      const isOn = m.status === 'on_leave';
      return `<tr data-id="${m.id}">
        <td>${fmtNum(m.id)}</td>
        <td>${m.name}</td>
        <td>${m.employeeNo}</td>
        <td>${m.unitName || '—'}</td>
        <td>${m.position || '—'}</td>
        <td><span class="badge ${isOn ? 'warn' : 'ok'}">${isOn ? 'في إجازة' : 'مفعّل'}</span></td>
        <td>${fmtNum(m.salary)}</td>
        <td><button class="tiny" data-act="toggle">${isOn ? 'إعادة تفعيل' : 'إجازة'}</button></td>
      </tr>`;
    }).join('');
    $('emp-pager').hidden = !employeesLoaded;
    $('emp-pager').innerHTML = `
      <span>${fmtNum((filters.page - 1) * filters.limit + 1)} – ${fmtNum(Math.min(filters.page * filters.limit, employees.length))} من ${fmtNum(employees.length)}</span>
      <button class="btn" ${filters.page <= 1 ? 'disabled' : ''} data-act="prev">السابق</button>
      <span class="muted">الصفحة ${filters.page}</span>
      <button class="btn" ${employeesLoaded && filters.page * filters.limit >= employees.length ? 'disabled' : ''} data-act="next">التالي</button>
    `;
    rows.querySelectorAll('[data-act="toggle"]').forEach(b => b.addEventListener('click', async e => {
      const tr = e.target.closest('tr'); const id = Number(tr.dataset.id);
      const m = employees.find(x => x.id === id);
      if (!m) return;
      const next = m.status === 'active' ? 'on_leave' : 'active';
      await api('POST', `/api/admin/hr/employee/${id}/toggle`, { enabled: next === 'active' });
      await loadEmployees();
    }));
  }

  async function showAddModal() {
    const units = unitOptions.map(u => `<option value="${u.key}">${u.label}</option>`).join('');
    const html = `
      <div class="modal" id="add-emp">
        <div class="modal-box">
          <div class="modal-title">إضافة موظف جديد</div>
          <div class="grid">
            <div class="field"><label>رقم الموظف</label><input id="a-en" placeholder="مثال: EMP-001"></div>
            <div class="field"><label>الاسم الكامل</label><input id="a-nm" placeholder="الاسم العربي"></div>
            <div class="field"><label>الرقم الشخصي</label><input id="a-pi" placeholder="الرقم الشخصي"></div>
            <div class="field"><label>البريد الإلكتروني</label><input id="a-em" type="email" placeholder="البريد"></div>
            <div class="field"><label>الهاتف</label><input id="a-ph" placeholder="الهاتف"></div>
            <div class="field"><label>تاريخ التعيين</label><input id="a-hd" type="date"></div>
            <div class="field"><label>الوحدة / القسم</label><select id="a-unit">${units}</select></div>
            <div class="field"><label>المسمى الوظيفي</label><input id="a-po" placeholder="المس 담당업무"></div>
            <div class="field"><label>الراتب الأساسي (ر.س)</label><input id="a-sal" type="number" min="0" placeholder="0"></div>
          </div>
          <div class="modal-foot">
            <button class="btn" data-act="close">إغلاق</button>
            <button class="btn primary" data-act="save">حفظ</button>
          </div>
        </div>
      </div>`;
    const m = el('div', { class: 'modal-backdrop' }, [html]);
    document.body.append(m);
    $('a-en').focus();
    $('a-hd').value = new Date().toISOString().slice(0, 10);
    $('a-sal').value = 0;
    $('m-save').addEventListener('click', async () => {
      try {
        await api('POST', '/api/admin/hr/employees', {
          employeeNo: $('a-en').value.trim(),
          name: $('a-nm').value.trim(),
          personalId: $('a-pi').value.trim(),
          email: $('a-em').value.trim(),
          phone: $('a-ph').value.trim(),
          hireDate: $('a-hd').value,
          unit_id: Number($('a-unit').value),
          position: $('a-po').value.trim(),
          salary: Number($('a-sal').value) || 0,
        });
        m.remove(); await loadEmployees();
      } catch (e) { alert(e.message); }
    });
    m.querySelector('[data-act="close"]').addEventListener('click', () => m.remove());
    m.addEventListener('click', e => { if (e.target.id === 'add-emp') m.remove(); });
  }

  async function showSalaryModal() {
    if (!currentEmpId) return;
    const { employee, salary } = await api('GET', `/api/admin/hr/employee/${currentEmpId}`);
    const html = `
      <div class="modal" id="sal-emp">
        <div class="modal-box">
          <div class="modal-title">الراتب ${employee.employeeNo}</div>
          <div class="grid">
            <div class="field"><label>الراتب الحالي (ر.س)</label><input id="s-am" type="number" value="${fmtNum(salary?.amount ?? employee.salary)}"></div>
            <div class="field"><label>التاريخ الفعّال</label><input id="s-da" type="date" value="${fmtDate(salary?.effectiveAt)}"></div>
            <div class="field"><label>ال.kind</label><select id="s-kind"><option>راتب أساسي</option><option>زيادة</option><option>خصم</option><option>تأمين</option></select></div>
          </div>
          <div class="modal-foot">
            <button class="btn" data-act="close">إغلاق</button>
            <button class="btn primary" data-act="save">حفظ</button>
          </div>
        </div>
      </div>`;
    const m = el('div', { class: 'modal-backdrop' }, [html]);
    document.body.append(m);
    $('s-emp').value = employee.name;
    $('s-am').value = fmtNum(salary?.amount ?? employee.salary);
    $('s-da').value = fmtDate(salary?.effectiveAt) || new Date().toISOString().slice(0, 10);
    $('m-save').addEventListener('click', async () => {
      try {
        await api('POST', '/api/admin/hr/salaries', {
          employee_id: currentEmpId,
          amount: Number($('s-am').value) || 0,
          effective_at: $('s-da').value ? new Date($('s-da').value).getTime() : Date.now(),
        });
        m.remove();
      } catch (e) { alert(e.message); }
    });
    m.querySelector('[data-act="close"]').addEventListener('click', () => m.remove());
    m.addEventListener('click', e => { if (e.target.id === 'sal-emp') m.remove(); });
  }

  async function showLeavesModal() {
    if (!currentEmpId) return;
    const { employee } = await api('GET', `/api/admin/hr/employee/${currentEmpId}`);
    const html = `
      <div class="modal" id="leaves-emp">
        <div class="modal-box">
          <div class="modal-title">إجازات ${employee.employeeNo}</div>
          <div class="grid">
            <div class="field"><label>نوع الإجازة</label><select id="l-type">${leaveTypeOpts.map(o => `<option value="${o.key}">${o.label}</option>`).join('')}</select></div>
            <div class="field"><label>من تاريخ</label><input id="l-from" type="date"></div>
            <div class="field"><label>إلى تاريخ</label><input id="l-to" type="date"></div>
            <div class="field"><label>عدد الأيام</label><input id="l-days" type="number" min="1"></div>
            <div class="field"><label>السبب</label><input id="l-why" placeholder="السبب"></div>
            <div class="field"><label>ملاحظات</label><input id="l-notes" placeholder="ملاحظات"></div>
          </div>
          <div class="modal-foot">
            <button class="btn" data-act="close">إغلاق</button>
            <button class="btn primary" data-act="save">إرسال طلب الإجازة</button>
          </div>
        </div>
      </div>`;
    const m = el('div', { class: 'modal-backdrop' }, [html]);
    document.body.append(m);
    $('l-from').value = new Date(Date.now() - 86400000 * 7).toISOString().slice(0, 10);
    $('l-to').value = new Date().toISOString().slice(0, 10);
    $('l-days').value = 1;
    $('m-save').addEventListener('click', async () => {
      try {
        await api('POST', '/api/admin/hr/leaves', {
          employee_id: currentEmpId,
          leave_type: $('l-type').value,
          start_date: $('l-from').value,
          end_date: $('l-to').value,
          days: Number($('l-days').value),
          reason: $('l-why').value.trim(),
          notes: $('l-notes').value.trim(),
        });
        m.remove();
      } catch (e) { alert(e.message); }
    });
    m.querySelector('[data-act="close"]').addEventListener('click', () => m.remove());
    m.addEventListener('click', e => { if (e.target.id === 'leaves-emp') m.remove(); });
  }

  async function showContractsModal() {
    if (!currentEmpId) return;
    const { employee } = await api('GET', `/api/admin/hr/employee/${currentEmpId}`);
    const html = `
      <div class="modal" id="ct-emp">
        <div class="modal-box">
          <div class="modal-title">عقود ${employee.employeeNo}</div>
          <div class="grid">
            <div class="field"><label>نوع العقد</label><select id="c-type">${contractTypeOpts.map(o => `<option value="${o.key}">${o.label}</option>`).join('')}</select></div>
            <div class="field"><label>عنوان العقد</label><input id="c-tit" placeholder="العنوان"></div>
            <div class="field"><label>من تاريخ</label><input id="c-from" type="date"></div>
            <div class="field"><label>إلى تاريخ</label><input id="c-to" type="date"></div>
            <div class="field"><label>الراتب</label><input id="c-sal" type="number" min="0"></div>
            <div class="field"><label>ملاحظات</label><input id="c-notes" placeholder="ملاحظات"></div>
          </div>
          <div class="modal-foot">
            <button class="btn" data-act="close">إغلاق</button>
            <button class="btn primary" data-act="save">إضافة عقد</button>
          </div>
        </div>
      </div>`;
    const m = el('div', { class: 'modal-backdrop' }, [html]);
    document.body.append(m);
    $('c-from').value = new Date().toISOString().slice(0, 10);
    $('c-to').value = new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10);
    $('c-sal').value = 0;
    $('m-save').addEventListener('click', async () => {
      try {
        await api('POST', '/api/admin/hr/contracts', {
          employee_id: currentEmpId,
          contract_type: $('c-type').value,
          title: $('c-tit').value.trim(),
          start_date: $('c-from').value,
          end_date: $('c-to').value,
          salary: Number($('c-sal').value) || 0,
          notes: $('c-notes').value.trim(),
        });
        m.remove();
      } catch (e) { alert(e.message); }
    });
    m.querySelector('[data-act="close"]').addEventListener('click', () => m.remove());
    m.addEventListener('click', e => { if (e.target.id === 'ct-emp') m.remove(); });
  }

  async function showDetailModal() {
    if (!currentEmpId) return;
    const { employee } = await api('GET', `/api/admin/hr/employee/${currentEmpId}`);
    const leaves = employee.leaves ?? [];
    const contracts = employee.contracts ?? [];
    const leavesHtml = leaves.map(l => `
      <tr><td class="nowrap">${fmtDate(l.startDate)} – ${fmtDate(l.endDate)}</td>
         <td>${leaveTypeOpts.find(o => o.key === l.leaveType)?.label || l.leaveType}</td>
         <td><span class="badge ${l.statusLabel === 'معتمد' ? 'ok' : l.statusLabel === 'مرفوض' ? 'reject' : ''} ${l.status === 'approved' ? 'ok' : ''} ${l.status === 'rejected' ? 'reject' : ''}">${l.statusLabel}</span></td>
         <td>${fmtNum(l.days)}</td>
         <td>${l.reason || '—'}</td></tr>
    `).join('') || '<tr><td colspan="5" class="muted">لا توجد إجازات سجلت</td></tr>';
    const contractsHtml = contracts.map(c => `
      <tr><td class="nowrap">${fmtDate(c.start)} – ${fmtDate(c.end)}</td>
         <td>${contractTypeOpts.find(o => o.key === c.contractType)?.label || c.contractType}</td>
         <td>${fmtNum(c.salary)}</td>
         <td>${c.title || '—'}</td></tr>
    `).join('') || '<tr><td colspan="4" class="muted">لا توجد عقود مسجّلة</td></tr>';
    const html = `
      <div class="modal" id="emp-detail">
        <div class="modal-box">
          <div class="modal-title">بيانات الموظف</div>
          <div class="detail-grid">
            <div><label>الرقم الموظفي</label><b>${employee.employeeNo}</b></div>
            <div><label>الاسم</label><b>${employee.name}</b></div>
            <div><label>الرقم الشخصي</label><b>${employee.personalId}</b></div>
            <div><label>البريد</label><b>${employee.email || '—'}</b></div>
            <div><label>الهاتف</label><b>${employee.phone || '—'}</b></div>
            <div><label>تاريخ التعيين</label><b>${fmtDate(employee.hireDate)}</b></div>
            <div><label>الوحدة</label><b>${employee.unitName || '—'}</b></div>
            <div><label>المسمى الوظيفي</label><b>${employee.position || '—'}</b></div>
            <div><label>الحالة</label><span class="badge ${employee.status === 'active' ? 'ok' : employee.status === 'on_leave' ? 'warn' : 'reject'}">${employee.status === 'active' ? 'مفعّل' : employee.status === 'on_leave' ? 'في إجازة' : 'منتهي'}</span></div>
            <div><label>الراتب الأساسي (ر.س)</label><b>${fmtNum(employee.salary)}</b></div>
            <div><label>تاريخ الانضمام</label><b>${fmtDate(employee.joinDate)}</b></div>
          </div>
          <div class="grid" style="margin-top:10px">
            <div class="card" style="flex:1">
              <div class="card-title">الراتب الحالي</div>
              <div class="detail-grid">
                <div><label>الراتب (ر.س)</label><b>${fmtNum(salary?.amount ?? employee.salary)}</b></div>
                <div><label>التاريخ الفعّال</label><b>${fmtDate(salary?.effectiveAt)}</b></div>
                <div><label>تم إنشاؤه من قبل</label><b>${salary?.createdBy ? 'فريق الإدارة' : 'النظام'}</b></div>
              </div>
            </div>
            <div class="card" style="flex:1">
              <div class="card-title">العقود</div>
              <div class="table">
                <div class="col head">المدّة</div><div class="col head">النوع</div><div class="col head">الراتب (ر.س)</div><div class="col head">العنوان</div>
                ${contractsHtml}
              </div>
            </div>
          </div>
          <div class="grid" style="margin-top:10px">
            <div class="card" style="flex:1">
              <div class="card-title">الإجازات</div>
              <div class="table">
                <div class="col head">المدّة</div><div class="col head">النوع</div><div class="col head">الحالة</div><div class="col head">الأيام</div><div class="col head">السبب</div>
                ${leavesHtml}
              </div>
            </div>
          </div>
          <div class="modal-foot">
            <button class="btn" data-act="close">إغلاق</button>
          </div>
        </div>
      </div>`;
    const m = el('div', { class: 'modal-backdrop' }, [html]);
    document.body.append(m);
    m.querySelector('[data-act="close"]').addEventListener('click', () => m.remove());
    m.addEventListener('click', e => { if (e.target.id === 'emp-detail') m.remove(); });
  }

  function renderSalaryTable(list) {
    if (!list || !list.salaries || !list.salaries.length) return '<tr><td colspan="5" class="muted">لا توجد سجلات رواتب</td></tr>';
    return list.salaries.map(s => `
      <tr class="nowrap"><td>${fmtNum(s.id)}</td>
        <td>${s.employeeName} (${s.employeeNo})</td>
        <td>${fmtNum(s.amount)}</td>
        <td>${fmtDate(s.effectiveAt)}</td>
        <td>${s.createdBy ? 'الإدارة' : 'النظام'}</td></tr>
    `).join('');
  }

  function renderLeavesTable(list) {
    if (!list || !list.leaves || !list.leaves.length) return '<tr><td colspan="7" class="muted">لا توجد طلبات إجازة</td></tr>';
    return list.leaves.map(l => `
      <tr><td class="nowrap">${fmtNum(l.id)}</td>
        <td>${l.employeeName} (${l.employeeNo})</td>
        <td>${leaveTypeOpts.find(o => o.key === l.leaveType)?.label || l.leaveType}</td>
        <td><span class="badge ${l.statusLabel === 'معتمد' ? 'ok' : l.statusLabel === 'مرفوض' ? 'reject' : ''}">${l.statusLabel}</span></td>
        <td class="nowrap">${fmtDate(l.startDate)} – ${fmtDate(l.endDate)}</td>
        <td>${fmtNum(l.days)}</td>
        <td>${l.reason || '—'}</td></tr>
    `).join('');
  }

  function setUnitOptions(list) { unitOptions = list; LS.setUnitOptions(list); }

  function populateUnits(selectEl) {
    selectEl.innerHTML = unitOptions.map(u => `<option value="${u.key}">${u.label}</option>`).join('');
  }

  $('load-hr').addEventListener('click', async () => {
    try {
      const r = await api('GET', '/api/admin/hr/options');
      const units = r.statuses ?? [];
      const sel = document.getElementById('f-status') || null;
      const opts = units.map(u => `<option value="${u.key}">${u.label}</option>`).join('');
      if (!document.getElementById('f-status').options.length) {
        const statusSel = el('select', { id: 'f-status', class: 'input' });
        statusSel.innerHTML = `<option value="">الحالة</option>${opts}`;
        $('f-wrap').append(statusSel);
      }
      const salOpts = units.map(u => `<option value="${u.key}">${u.label}</option>`).join('');
      const st = document.getElementById('f-status');
      if (st && !st.options.length) st.innerHTML = `<option value="">الحالة</option>${salOpts}`;
    } catch (e) { /* تجاهل التهيئة غير الحرجة */ }
    await loadEmployees();
  });

  $('load-hr').addEventListener('click', async () => {
    try { await loadEmployees(); $('emp-pager').hidden = false; } catch (e) { alert(e.message); }
  });

  const exp = window.ERP_HR || {};
  window.ERP_HR = Object.assign(window.ERP_HR, {
    init, set currentId(v) { currentEmpId = v; }, get currentId() { return currentEmpId; },
  });

  // مسارات العميل: استدعاء دوال الداخلية من عناصر خارجي (عن طريق مكتبة وحدة الإدارة)
  if (window.UA) {
    window.UA.registry['hr.init'] = () => init();
    window.UA.registry['hr.loadOptions'] = async () => { const r = await api('GET', '/api/admin/hr/options'); setUnitOptions(r.statuses || []); };
  }
} catch (e) {
  console.error('HR UI init error:', e);
}
